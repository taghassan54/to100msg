-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 27, 2024 at 10:31 PM
-- Server version: 5.7.44-log
-- PHP Version: 8.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `to100msg`
--

-- --------------------------------------------------------

--
-- Table structure for table `apps`
--

CREATE TABLE `apps` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `device_id` bigint(20) UNSIGNED DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `apps`
--

INSERT INTO `apps` (`id`, `uuid`, `key`, `user_id`, `device_id`, `title`, `website`, `status`, `created_at`, `updated_at`) VALUES
(1, '6c1963ac-2515-4e68-9f48-593ced0dc990', 'e1bdc00e-b7e0-4a59-83b6-f6cec4aab2c3', 2, 4, 'app', 'https://webhook.site/b677f948-b388-4d79-9702-086d8568b503', 1, '2024-08-27 17:35:01', '2024-08-27 17:35:01');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'category',
  `status` int(11) NOT NULL DEFAULT '1',
  `is_featured` int(11) NOT NULL DEFAULT '1',
  `lang` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `slug`, `type`, `status`, `is_featured`, `lang`, `created_at`, `updated_at`) VALUES
(1, '#', '/uploads/23/03/16781015652CQnP1QNhw2T4te7n4J2.png', 'brand', 1, 1, 'en', '2023-03-06 16:19:25', '2023-03-06 16:19:25'),
(2, '#', '/uploads/23/03/1678101574iv7f5NuUi7wXfkq4DQwf.png', 'brand', 1, 1, 'en', '2023-03-06 16:19:34', '2023-03-06 16:19:34'),
(3, '#', '/uploads/23/03/1678101584RYE53fStsc5Rbnwm1Acq.png', 'brand', 1, 1, 'en', '2023-03-06 16:19:44', '2023-03-06 16:19:44'),
(4, '#', '/uploads/23/03/1678101592TSj8SeYx7JZM0dhRYq1k.png', 'brand', 1, 1, 'en', '2023-03-06 16:19:52', '2023-03-06 16:19:52'),
(5, '#', '/uploads/23/03/1678101601r2uMoEBkUc9cN4n60XTn.png', 'brand', 1, 1, 'en', '2023-03-06 16:20:01', '2023-03-06 16:20:01'),
(6, 'Chatbot', 'chatbot', 'blog_category', 1, 1, 'en', '2023-03-06 23:35:06', '2023-03-06 23:35:06'),
(7, 'Target marketing', 'target-marketing', 'blog_category', 1, 1, 'en', '2023-03-06 23:35:30', '2023-03-06 23:35:30'),
(8, 'Button message', 'button-message', 'blog_category', 1, 1, 'en', '2023-03-06 23:36:44', '2023-03-06 23:36:44'),
(9, 'Template message', 'template-message', 'blog_category', 1, 1, 'en', '2023-03-06 23:36:50', '2023-03-06 23:36:50'),
(10, 'Location message', 'location-message', 'blog_category', 1, 1, 'en', '2023-03-06 23:37:56', '2023-03-06 23:37:56'),
(11, 'support', 'support', 'tags', 1, 1, 'en', '2023-03-06 23:38:24', '2023-03-06 23:38:24'),
(12, 'marketing', 'marketing', 'tags', 1, 1, 'en', '2023-03-06 23:38:46', '2023-03-06 23:38:46'),
(13, 'whatsapp', 'whatsapp', 'tags', 1, 1, 'en', '2023-03-06 23:39:05', '2023-03-06 23:39:05'),
(14, 'chatbot', 'chatbot', 'tags', 1, 1, 'en', '2023-03-06 23:39:16', '2023-03-06 23:39:16'),
(16, '#', '/uploads/23/04/1681069463TyzbAs8krJWkdmfle2AK.png', 'brand', 1, 1, 'integration', '2023-04-09 23:44:23', '2023-04-09 23:44:23'),
(17, '#', '/uploads/23/04/1681069481dhzTeKTgyImXGO6uxfKS.png', 'brand', 1, 1, 'integration', '2023-04-09 23:44:41', '2023-04-09 23:44:41'),
(18, '#', '/uploads/23/04/1681069492WKuK8M4N4F0zCq5rTLrm.png', 'brand', 1, 1, 'integration', '2023-04-09 23:44:52', '2023-04-09 23:44:52'),
(19, '#', '/uploads/23/04/16810695031BJ8EGeeQRaQsqsMAAQL.png', 'brand', 1, 1, 'integration', '2023-04-09 23:45:03', '2023-04-09 23:45:03'),
(20, '#', '/uploads/23/04/1681069512lsGeQfcBynLLEfPEDmEy.png', 'brand', 1, 1, 'integration', '2023-04-09 23:45:12', '2023-04-09 23:45:12'),
(21, '#', '/uploads/23/04/1681069522nLsyBhcnY7Im1u9MZXMl.png', 'brand', 1, 1, 'integration', '2023-04-09 23:45:22', '2023-04-09 23:45:22'),
(22, '#', '/uploads/23/04/1681069535bhMiLvhKrd6rBnOvm8LC.png', 'brand', 1, 1, 'integration', '2023-04-09 23:45:35', '2023-04-09 23:45:35');

-- --------------------------------------------------------

--
-- Table structure for table `categorymetas`
--

CREATE TABLE `categorymetas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deviceorders`
--

CREATE TABLE `deviceorders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `trx` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `phone` int(11) NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

CREATE TABLE `devices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qr` text COLLATE utf8mb4_unicode_ci,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `bot_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `welcomeMessage` text COLLATE utf8mb4_unicode_ci,
  `errorMessage` text COLLATE utf8mb4_unicode_ci,
  `errorMessageEnable` int(11) NOT NULL DEFAULT '0',
  `welcomeMessageEnable` int(11) NOT NULL DEFAULT '0',
  `resendToMain` int(11) NOT NULL DEFAULT '10',
  `webhook_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `devices`
--

INSERT INTO `devices` (`id`, `uuid`, `user_id`, `name`, `phone`, `user_name`, `qr`, `meta`, `status`, `created_at`, `updated_at`, `bot_status`, `welcomeMessage`, `errorMessage`, `errorMessageEnable`, `welcomeMessageEnable`, `resendToMain`, `webhook_url`) VALUES
(2, '0a3637d9-bf22-42c4-83a6-39080fe513a2', 2, 'd1', NULL, NULL, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARQAAAEUCAYAAADqcMl5AAAAAklEQVR4AewaftIAABJpSURBVO3BQY7AxrLgQFLo+1+Z42WuChBU3fZ/kxH2D9Za64KHtda65GGttS55WGutSx7WWuuSh7XWuuRhrbUueVhrrUse1lrrkoe11rrkYa21LnlYa61LHtZa65KHtda65GGttS55WGutS374SOUvVZyoTBUnKicVX6hMFZPKVHGiMlV8oTJVTConFW+oTBWTylQxqfymihOVk4oTlZOKSeUvVXzxsNZalzystdYlD2utdckPl1XcpPKFylQxVUwqk8pUMan8pYovVL6o+E0Vk8pUMalMFScqJypTxRsqU8VNFTep3PSw1lqXPKy11iUPa611yQ+/TOWNijdU3lCZKqaKSeUvqUwVb6icVEwqk8qJylTxRsWJylTxmyq+qDhR+U0qb1T8poe11rrkYa21LnlYa61LfvgfUzGpvKFyovKXVN6o+E0Vb6h8oTJVTBUnKm+oTBUnKlPFScWk8r/kYa21LnlYa61LHtZa65If/seoTBWTyknFicq/qeJE5TepvFHxhspUMalMFZPKGypTxUnFicqJylTxv+RhrbUueVhrrUse1lrrkh9+WcVfqnhD5aRiqnhDZVL5QuWk4kTlpOINlaliUjmpmComlTcqTlROVE4qvqi4qeK/5GGttS55WGutSx7WWuuSHy5T+S9RmSomlaliUpkqJpWp4qRiUpkqJpWpYlI5UZkqJpUTlanii4pJZao4qZhUpopJZaqYVKaKSeVEZaqYVE5UpooTlf+yh7XWuuRhrbUueVhrrUt++Kjiv0TlROVE5d+kcqLylyreUJkqvqiYVKaKk4pJ5URlqphUpopJZar4ouL/koe11rrkYa21LnlYa61L7B98oDJVTCo3VZyonFScqEwVk8pUMam8UTGp3FQxqfxfUvGFylRxonJSMalMFZPKVPGGyk0Vv+lhrbUueVhrrUse1lrrkh/+YypOVL5QmSr+l1T8pYqbVN5QmSpOVKaKqeJE5URlqnhD5aRiUjmpmFSmipse1lrrkoe11rrkYa21Lvnho4o3Kt5QmSomlS9UpoqTijcqTlROKiaVqWJS+TepnFTcVHFSMamcqJxU3KQyVUwqk8pJxUnFpDJVfPGw1lqXPKy11iUPa611yQ8fqUwVJypTxaQyVUwqJxWTyknFpPJGxYnKVDFVnKicqEwVN6lMFZPKVDGpnKhMFZPKVPGGylQxqUwVJypTxRcVf0llqrjpYa21LnlYa61LHtZa6xL7Bx+onFRMKn+pYlKZKk5UbqqYVE4qJpWpYlKZKiaVNypuUjmpmFSmihOVNyreULmp4kTlpOILlanii4e11rrkYa21LnlYa61L7B/8h6hMFV+ovFExqXxRMalMFZPKScWkclLxhspJxaQyVbyhclJxovJGxaQyVbyhMlV8ofJFxYnKScUXD2utdcnDWmtd8rDWWpf88MtUpoqTiknlpGJSmSomlROVqeINlUllqnij4o2KE5U3KiaVqWJSmSomlaliUplU3qi4SWWqmCpOVN6omFSmijdU/tLDWmtd8rDWWpc8rLXWJT98pHJSMam8UfFGxaQyVUwqb6h8ofKbVE4qTlQmlaliUrmpYlI5qfiiYlJ5Q2WqOKk4UTlROamYKiaV3/Sw1lqXPKy11iUPa611if2DD1TeqDhROak4UZkqJpWp4kTljYpJ5aTiRGWqmFROKk5UpopJ5aTiROWNii9U3qh4Q+WLikllqjhRmSomlaliUjmp+OJhrbUueVhrrUse1lrrkh8+qnhD5aTiRGWqmComlanii4oTlaniJpWp4g2VNyq+qDhRmVSmipsqJpWTiqniRGWqmFSmiknlpGJS+aLipoe11rrkYa21LnlYa61LfrhM5Y2KSeWk4kTlRGWqOKl4o2JSOan4QmWqOKmYVCaVNyomlZOKL1SmipOKSeWkYlKZKk4qvqiYVL5QmSomlanii4e11rrkYa21LnlYa61LfvhlFScqJxWTylQxVUwqb6hMFZPKGxUnKm9UTCqTylRxUnGi8kXFScUXKicqU8VvUpkqpoo3KiaVk4oTld/0sNZalzystdYlD2utdYn9g4tUTireUDmpmFSmikllqjhRualiUpkqJpWTijdUpopJZaqYVN6omFS+qDhReaNiUvmi4kRlqjhROamYVKaKSWWquOlhrbUueVhrrUse1lrrkh8uq5hU3lCZKk5UTlTeUJkqTlSmikllUjlR+UJlqvhLFW9UvKEyVbxRcVJxonKiMlVMFTepnKicqEwVXzystdYlD2utdcnDWmtd8sNHKlPFicobKicVk8pU8UbFv6liUrmp4qTipOJE5aTiDZWpYlKZKiaVL1SmiknlDZWpYlKZKt5QmSomld/0sNZalzystdYlD2utdckPH1W8UTGpnFRMKicVk8pJxaQyVUwqU8WkMlXcVDGpTBUnKlPFpDJVnKhMFZPKicpU8YXKVHGiMlVMFScVJyonKicqb1T8mx7WWuuSh7XWuuRhrbUusX9wkcobFZPKScVvUpkqJpU3Kk5UpooTlTcqvlA5qXhD5aaKE5Wp4guVk4oTlTcqJpWpYlI5qfhND2utdcnDWmtd8rDWWpfYP/hFKlPFpDJVnKhMFZPKVDGpTBVfqEwVJyonFW+oTBUnKlPFpHJScaIyVUwqU8WkMlW8ofJGxaQyVUwqb1S8ofJGxYnKScVND2utdcnDWmtd8rDWWpfYP/hAZao4UZkqTlTeqHhDZaqYVE4qTlTeqJhU3qg4UflLFScqU8WJym+qmFSmihOVqWJSeaNiUjmpOFE5qfjiYa21LnlYa61LHtZa6xL7BxepTBU3qZxUTConFW+oTBUnKlPFGypTxaRyUvGFylQxqUwVJypTxU0qU8WkMlVMKlPFTSpvVJyonFRMKlPFTQ9rrXXJw1prXfKw1lqX/PAvU/kvU5kqJpWpYqqYVE4qpopJZar4QuUNlZtUpopJZar4TRWTyhcVU8WkcqLyhcqJylTxxcNaa13ysNZalzystdYlP3ykclPFGyqTyknFpHJSMamcqJxUfFExqdxU8YbKFxUnFZPKVHGicqIyVUwVJypTxRcVb6icVPylh7XWuuRhrbUueVhrrUt++KjiN6lMFV+onFRMKlPFicpUMalMFZPKScVUMalMFScqJypTxYnKVDFVnKicVJxUTCpTxaQyqXyhcpPKVHFSMam8UfHFw1prXfKw1lqXPKy11iU//DKVLyreqLipYlI5qTipOKmYVG5SeaPijYpJZaqYVKaKSWVSualiUpkqJpWTiknli4ovKiaV3/Sw1lqXPKy11iUPa611if2DP6Tyb6p4Q+WNikllqphUTipuUvkvq5hUTipOVE4qJpWpYlL5v6TiLz2stdYlD2utdcnDWmtd8sNlKlPFScWkMlVMKlPFGypTxRsVk8qkcqLyhcoXFZPKScWkclJxonKiMlVMKpPKGxV/qeILlZOKL1Smii8e1lrrkoe11rrkYa21LrF/8ItUpooTlZOKSeWk4jepTBVfqEwVJypfVJyovFFxonJScZPKScWJylRxojJVTCp/qWJSOan44mGttS55WGutSx7WWuuSHz5SOamYVKaKk4qTihOVqWJSOamYVKaKL1SmijcqJpWp4kRlqpgq3lCZKt5QmSpuqphUTiq+ULmpYlJ5o2JSuelhrbUueVhrrUse1lrrEvsHv0jlpGJSOan4QmWqOFE5qZhUTiq+UJkq3lCZKiaVNyreUDmpmFSmihOVNypOVN6omFTeqHhDZaqYVE4qbnpYa61LHtZa65KHtda65IePVE4qTlROKr5QmSomlb+kMlVMKlPFicobFZPKVHGi8kXFicpUMalMFV+onFRMKicqU8Wk8obKScWkMlX8pYe11rrkYa21LnlYa61LfviXVZyonFRMKlPFpDJVTCpTxaRyUjGpnKhMFZPKVHGicqIyVZyoTBUnKl9UTCpvVEwqU8WJyqQyVUwqU8VJxaQyqfwmlanipoe11rrkYa21LnlYa61L7B/8IpWpYlKZKk5Ubqo4UXmjYlKZKt5QOak4UZkqvlCZKiaVk4oTlTcqTlS+qJhUTireUJkq3lCZKt5QmSq+eFhrrUse1lrrkoe11rrkh8tUpopJ5UTlpOINlaniROWk4kRlqvii4kTlC5UvVKaKN1TeqHijYlKZKiaVm1ROKiaVqeINlZOK3/Sw1lqXPKy11iUPa611yQ+/TGWqmFROKiaVk4qpYlJ5o+JEZao4UZkqJpU3Kr6oOFGZKiaVN1TeqJhUvqg4qXijYlKZKm5SmSq+qLjpYa21LnlYa61LHtZa65IfPlI5qZhUTiomlZOKE5WpYlKZKiaVL1TeqPhNKlPFpDJVvKFyUnFTxYnKicpJxYnKicpU8YbKicpUMam8UfHFw1prXfKw1lqXPKy11iU/fFQxqZxUvFFxk8pUMalMFScqk8oXKlPFpDJVTConFZPKicpJxYnKicobFZPKVDFV3FRxk8pUcaLyRsWJyk0Pa611ycNaa13ysNZal9g/+EDli4oTlZOKSeWk4g2VLypOVL6omFSmii9UpooTld9UcaLyRsWkclPFpPKbKiaVqWJSmSq+eFhrrUse1lrrkoe11rrkh19WMamcqEwVk8qk8obKVHFSMalMFZPKGxVvqEwqb6icVEwVb1RMKlPFpHJSMan8pYpJ5TdVnKhMFV9U3PSw1lqXPKy11iUPa611yQ8fVZyoTBWTylQxqUwVk8pUMalMFScqU8VUcVJxovJGxUnFGxVvqHxR8ZsqJpUvKiaVqWJSmSreqJhU3lA5qZhUTiq+eFhrrUse1lrrkoe11rrkh39ZxUnFScWkMlWcqJyoTBWTyknFScVNKicVk8obFScqf0llqnhD5SaVqeJE5Y2KLyomlZse1lrrkoe11rrkYa21Lvnhj6l8UXFTxYnKScUXKlPFScWkclJxUnGi8kbFpHJTxRcqU8WJyqRyUvGXVKaKSeUvPay11iUPa611ycNaa13yw7+s4g2Vk4pJ5YuKN1SmiqniRGWqmFROKk5UblKZKqaKSeULlS8qTlSmijdUpoqpYlI5qZhUpoovKm56WGutSx7WWuuSh7XWuuSHf5nKFxWTylQxqUwVJyonFVPFicoXFZPKpPJGxRsqU8WkclLxhspUcaLyhspUMalMFZPKVDGpfKHyhspJxaQyVXzxsNZalzystdYlD2utdYn9gw9U3qiYVKaKN1SmikllqphUTipOVH5TxaQyVUwqU8Wk8kXFX1I5qZhU3qiYVE4qTlSmiv+fPKy11iUPa611ycNaa11i/+ADlS8qTlROKiaVqeINlaniROWmijdUpoo3VG6qmFTeqPhNKlPFGypvVEwqv6liUnmj4ouHtda65GGttS55WGutS+wf/B+m8kbFGyonFZPKVDGpTBWTylQxqZxUTCpTxaQyVbyhclLxhspU8YbKFxUnKicVJyonFW+ovFExqUwVXzystdYlD2utdcnDWmtd8sNHKn+pYqp4Q2WqOKk4UTlRmSomlanipOJEZar4QmWqOKmYVE4q3lA5qThRmSomlaliqphUJpWbVKaKNyomld/0sNZalzystdYlD2utdckPl1XcpHKiMlVMKr+p4jepTBWTylRxU8UbKm+ovFHxl1SmiqliUrmp4o2Kk4pJ5aaHtda65GGttS55WGutS374ZSpvVHyhMlVMKicqU8UbKlPFpDJVTCpTxaTyhcqJyhcVk8obFZPKVHGi8kXFpDKpvFFxojKpfKEyVfylh7XWuuRhrbUueVhrrUt++B+nMlWcVEwqb1S8oTJV3KQyVZyovFExqUwVk8pUcVIxqUwVU8WkMlW8UTGpTBWTyonKVDGpnFRMKicqU8VvelhrrUse1lrrkoe11rrkh/8xFScqJxVTxRsqU8UbKlPFFxVvVEwqU8UbKlPFpHKTylQxqUwVk8pU8UbFpDJVfKEyVZyo/KWHtda65GGttS55WGutS374ZRW/qeJE5aTiN6l8oTJVTCqTylQxqUwVk8pU8UXFpDJVvKEyqUwVk8pUcVIxqUwVJypTxaQyVbxRMamcVPylh7XWuuRhrbUueVhrrUt+uEzlL6lMFScVJypTxRsVk8pNKicVJxVfqEwVJyonKlPFpDJVvFExqUwVb6icVJxUvFFxUnGi8pce1lrrkoe11rrkYa21LrF/sNZaFzystdYlD2utdcnDWmtd8rDWWpc8rLXWJQ9rrXXJw1prXfKw1lqXPKy11iUPa611ycNaa13ysNZalzystdYlD2utdcnDWmtd8v8AQ+KzhcuzfB8AAAAASUVORK5CYII=', NULL, 0, NULL, NULL, '', NULL, NULL, 0, 0, 10, NULL),
(3, '6d29d0b5-b66b-4bd5-969e-939217cc516d', 3, 'd1', NULL, NULL, NULL, NULL, 0, NULL, NULL, '', NULL, NULL, 0, 0, 10, NULL),
(4, '04dee986-6bf3-4d78-b0fd-07f9f696e379', 2, 'Device', '971569501867', '', NULL, NULL, 1, NULL, NULL, '0', NULL, NULL, 0, 0, 5, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gateways`
--

CREATE TABLE `gateways` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charge` double NOT NULL DEFAULT '0',
  `multiply` double NOT NULL DEFAULT '1',
  `namespace` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `min_amount` double NOT NULL DEFAULT '1',
  `max_amount` double NOT NULL DEFAULT '1000',
  `is_auto` int(11) NOT NULL DEFAULT '0',
  `image_accept` int(11) DEFAULT NULL,
  `test_mode` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `phone_required` int(11) NOT NULL DEFAULT '0',
  `data` text COLLATE utf8mb4_unicode_ci,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gateways`
--

INSERT INTO `gateways` (`id`, `name`, `currency`, `logo`, `charge`, `multiply`, `namespace`, `min_amount`, `max_amount`, `is_auto`, `image_accept`, `test_mode`, `status`, `phone_required`, `data`, `comment`, `created_at`, `updated_at`) VALUES
(1, 'paypal', 'usd', '/uploads/payment-gateway/paypal.png', 2, 1, 'App\\Gateway\\Paypal', 1, 1000, 1, 0, 1, 0, 0, '{\"client_id\":\"\",\"client_secret\":\"\"}', NULL, '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(2, 'stripe', 'usd', '/uploads/payment-gateway/stripe.png', 2, 1, 'App\\Gateway\\Stripe', 1, 1000, 1, 0, 1, 0, 0, '{\"publishable_key\":\"\",\"secret_key\":\"\"}', NULL, '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(3, 'mollie', 'usd', '/uploads/payment-gateway/mollie.png', 2, 1, 'App\\Gateway\\Mollie', 1, 1000, 1, 0, 1, 1, 0, '{\"api_key\":\"test_WqUGsP9qywy3eRVvWMRayxmVB5dx2r\"}', NULL, '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(4, 'paystack', NULL, '/uploads/payment-gateway/paystack.png', 2, 1, 'App\\Gateway\\Paystack', 1, 1000, 1, 0, 1, 0, 0, '{\"public_key\":\"\",\"secret_key\":\"\"}', NULL, '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(5, 'razorpay', 'inr', '/uploads/payment-gateway/rajorpay.png', 2, 1, 'App\\Gateway\\Razorpay', 1, 10000, 1, 0, 1, 0, 0, '{\"key_id\":\"\",\"key_secret\":\"\"}', NULL, '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(6, 'instamojo', 'inr', '/uploads/payment-gateway/instamojo.png', 2, 1, 'App\\Gateway\\Instamojo', 1, 1000, 1, 0, 1, 0, 1, '{\"x_api_key\":\"\",\"x_auth_token\":\"\"}', NULL, '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(7, 'toyyibpay', 'rm', '/uploads/payment-gateway/toyybipay.png', 2, 1, 'App\\Gateway\\Toyyibpay', 1, 1000, 1, 0, 1, 0, 1, '{\"user_secret_key\":\"\",\"cateogry_code\":\"\"}', NULL, '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(8, 'flutterwave', NULL, '/uploads/payment-gateway/flutterwave.png', 2, 1, 'App\\Gateway\\Flutterwave', 1, 1000, 1, 0, 1, 0, 1, '{\"public_key\":\"\",\"secret_key\":\"\",\"encryption_key\":\"\",\"payment_options\":\"card\"}', NULL, '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(9, 'payu', NULL, '/uploads/payment-gateway/payu.png', 2, 1, 'App\\Gateway\\Payu', 1, 1000, 1, 0, 1, 0, 1, '{\"merchant_key\":\"\",\"merchant_salt\":\"\",\"auth_header\":\"\"}', NULL, '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(10, 'thawani', NULL, '/uploads/payment-gateway/uhawan.png', 1, 1, 'App\\Gateway\\Thawani', 1, 1000, 1, 0, 1, 0, 1, '{\"secret_key\":\"\",\"publishable_key\":\"\"}', NULL, '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(11, 'mercadopago', NULL, '/uploads/payment-gateway/mercado-pago.png', 2, 1, 'App\\Gateway\\Mercado', 1, 1000, 1, 0, 1, 0, 0, '{\"secret_key\":\"\",\"public_key\":\"\"}', NULL, '2023-09-17 20:12:41', '2023-09-17 20:12:41');

-- --------------------------------------------------------

--
-- Table structure for table `groupcontacts`
--

CREATE TABLE `groupcontacts` (
  `group_id` bigint(20) UNSIGNED NOT NULL,
  `contact_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `position`, `data`, `lang`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Header', 'main-menu', '[{\"text\":\"Home\",\"href\":\"/\",\"icon\":\"\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Pricing\",\"href\":\"/pricing\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"About\",\"href\":\"/about\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Features\",\"href\":\"/features\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Blogs\",\"href\":\"/blogs\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Contact\",\"href\":\"/contact\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"login\",\"icon\":\"\",\"href\":\"/login\",\"target\":\"_self\",\"title\":\"\"}]', 'en', '1', '2023-09-17 20:12:41', '2024-08-27 17:52:33');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_11_04_174202_create_deviceorders_table', 1),
(6, '2022_11_04_174204_create_devices_table', 1),
(7, '2022_11_04_174205_create_apps_table', 1),
(8, '2022_11_07_154504_create_templates_table', 1),
(9, '2022_11_24_200110_create_smstransactions_table', 1),
(10, '2022_11_26_175433_create_smstesttransactions_table', 1),
(11, '2022_12_09_155744_create_schedulemessages_table', 1),
(12, '2022_12_09_164619_create_contacts_table', 1),
(13, '2022_12_09_165556_create_schedulecontacts_table', 1),
(14, '2023_02_04_181414_create_replies_table', 1),
(15, '2023_02_11_160234_create_supports_table', 1),
(16, '2023_02_11_160247_create_supportlogs_table', 1),
(17, '2023_02_12_163752_create_plans_table', 1),
(18, '2023_02_12_163758_create_gateways_table', 1),
(19, '2023_02_12_163759_create_orders_table', 1),
(20, '2023_02_12_170152_create_notifications_table', 1),
(21, '2023_02_13_130039_create_permission_tables', 1),
(22, '2023_02_14_181559_create_options_table', 1),
(23, '2023_02_19_082229_create_posts_table', 1),
(24, '2023_02_19_082240_create_categories_table', 1),
(25, '2023_02_19_082254_create_postcategories_table', 1),
(26, '2023_02_19_084742_create_categorymetas_table', 1),
(27, '2023_02_19_084751_create_postmetas_table', 1),
(28, '2023_02_19_085200_create_menus_table', 1),
(29, '2023_03_02_184250_create_jobs_table', 1),
(30, '2023_03_08_151642_create_groups_table', 1),
(31, '2023_03_08_151657_create_groupcontacts_table', 1),
(32, '2023_09_21_173059_add_token_to_users_table', 2),
(33, '2023_09_22_173055_add_message_timestamp_to_smstransactions', 2),
(34, '2023_09_22_182227_add_bot_status_to_devices', 2),
(35, '2023_09_22_182413_modify_bot_status_column', 2),
(36, '2023_09_22_183141_add_welcome_message_to_devices', 2),
(37, '2023_09_24_164559_add_webhook_url_to_devices', 2),
(38, '2023_10_07_175436_webhooks', 2),
(39, '2023_11_05_230432_add_message_content_and_id_to_smstransactions', 2),
(40, '2024_04_06_162411_add_additional_fields_to_device', 2);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seen` int(11) NOT NULL DEFAULT '0',
  `is_admin` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `title`, `comment`, `url`, `seen`, `is_admin`, `created_at`, `updated_at`) VALUES
(1, 3, 'Subscription revenueal notice', 'Your subscription will end soon the due date is September-27-2023', '/user/subscription/2', 0, 0, '2023-09-20 08:00:36', '2023-09-20 08:00:36');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `key`, `value`, `lang`) VALUES
(1, 'primary_data', '{\"logo\":\"\\/uploads\\/23\\/04\\/16809883098PkELjA7CZYT8XyFgvaU.png\",\"favicon\":\"uploads\\/favicon.png\",\"contact_email\":\"taghassan54@gmail.com\",\"contact_phone\":\"971569501867\",\"address\":\"Dubai Dear Al Braha\",\"socials\":{\"facebook\":\"https:\\/\\/www.facebook.com\\/\",\"youtube\":\"https:\\/\\/youtube.com\\/\",\"twitter\":\"https:\\/\\/twitter.com\\/\",\"instagram\":\"https:\\/\\/www.instagram.com\\/\",\"linkedin\":\"https:\\/\\/linkedin.com\\/\"},\"footer_logo\":\"\\/uploads\\/23\\/04\\/16809882645YTjTdvCTduL5D1hCfX7.png\"}', 'en'),
(2, 'tax', '0', 'en'),
(3, 'base_currency', '{\"name\":\"AED\",\"icon\":\"AED\",\"position\":\"left\"}', 'en'),
(4, 'invoice_data', '{\"company_name\":\"Whatserve\",\"address\":\"San francisco\",\"city\":\"California\",\"country\":\"USA\",\"post_code\":\"12345\"}', 'en'),
(5, 'languages', '{\"en\":\"English\"}', 'en'),
(6, 'seo_home', '{\"site_name\":\"Home\",\"matatag\":\"\",\"matadescription\":\"\",\"twitter_site_title\":\"home\",\"preview\":\"\"}', 'en'),
(7, 'seo_blog', '{\"site_name\":\"Blogs\",\"matatag\":\"\",\"matadescription\":\"\",\"preview\":\"\"}', 'en'),
(8, 'seo_about', '{\"site_name\":\"About Us\",\"matatag\":\"\",\"matadescription\":\"\",\"preview\":\"\"}', 'en'),
(9, 'seo_pricing', '{\"site_name\":\"Pricing\",\"matatag\":\"\",\"matadescription\":\"\",\"preview\":\"\"}', 'en'),
(10, 'seo_contact', '{\"site_name\":\"Contact Us\",\"matatag\":\"\",\"matadescription\":\"\",\"preview\":\"\"}', 'en'),
(11, 'seo_faq', '{\"site_name\":\"Faq\",\"matatag\":\"\",\"matadescription\":\"\",\"preview\":\"\"}', 'en'),
(12, 'seo_team', '{\"site_name\":\"Our Team\",\"matatag\":\"\",\"matadescription\":\"\",\"preview\":\"\"}', 'en'),
(13, 'seo_features', '{\"site_name\":\"Features\",\"matatag\":\"\",\"matadescription\":\"\",\"preview\":\"\"}', 'en'),
(14, 'seo_how_its_works', '{\"site_name\":\"How its work\",\"matatag\":\"\",\"matadescription\":\"\",\"preview\":\"\"}', 'en'),
(15, 'header_footer', '{\"header\":{\"announcement_type\":null,\"announcement_title\":null,\"announcement_link\":\"\\/contact\"},\"footer\":{\"title\":\"Ready To Launch \\ud83d\\ude80\",\"description\":\"Automate your conversations and boost your marketing strategy\",\"right_image_link\":\"\\/pricing\",\"left_image_link\":\"\\/pricing\"},\"footer_button_image\":\"\\/uploads\\/23\\/03\\/1678211121jY056A0fKjEFLQN7lJeZ.png\",\"footer_left_button_image\":\"\\/uploads\\/23\\/03\\/1678211121yYLog9HsVoV5QCJAvX4g.png\"}', 'en'),
(16, 'home-page', '{\"heading\":{\"title\":\"Boost your marketing with <strong>Zero To Hundred<\\/strong>\",\"left_button_link\":\"\\/pricing\",\"right_button_link\":\"\\/pricing\"},\"brand\":{\"title\":\"Over 1K+ software businesses growing with Zero To Hundred\",\"status\":\"active\"},\"cta\":{\"title\":\"More than 1,00 teams use our platform\"},\"features\":{\"title\":\"Explore Our Amazing Features \\ud83d\\udd25\",\"status\":\"active\"},\"platform\":{\"title\":\"Start Building Chatbot using Zero To Hundred\",\"description\":\"We provide a bird`s eye perspective of your entire bot, which aids in the development of a highly engaging bot. You can create, test, and build chatbots graphically using a single no-code online interface.\",\"button_title\":\"Get Started\",\"button_link\":\"\\/pricing\"},\"account_area\":{\"heading\":\"Create your free account\",\"subheading\":\"It takes only 3 minutes to get started\",\"description\":\"Plug your messaging channels, install your widget and\\r\\nyou\\u2019re ready to go\",\"form_link\":\"\\/register\\/2\",\"status\":\"active\",\"button_link1\":\"\\/pricing\",\"button_link2\":\"\\/pricing\"},\"about\":{\"title\":\"Whatsapp Automation\",\"description\":\"A WhatsApp bot can work around the clock and can handle multiple requests simultaneously, which means that it is always available to assist customers, even outside of regular business hours.\",\"action_area_title\":\"Lets create a Whatsapp chatbot \\ud83d\\ude80\"},\"top_faq\":{\"title\":\"Zero To Hundred For Creatives business \\ud83d\\ude07\",\"description\":\"Zero To Hundred is the best quaint james bond victoria sponge happy days cras arse over blatant\"},\"integration\":{\"title\":\"Top Integration \\ud83e\\udd1d\\ud83c\\udffb\"},\"testimonial\":{\"title\":\"User Feedback \\ud83c\\udf96\\ufe0f\"},\"calltoaction\":{\"title\":\"Discover a better way to <br> manage spendings\",\"button_title\":\"Get Started Now\",\"button_link\":\"\\/pricing\"},\"right_button_image\":\"\\/uploads\\/23\\/03\\/16782229849w7zEZUReAELpYZzBhfy.png\",\"left_button_image\":\"\\/uploads\\/23\\/03\\/16782229844xnXg3VVbopZTUmCVkoP.png\",\"hero_left_image\":\"\\/uploads\\/23\\/04\\/1680991267dcZhpgfhm46WulMpbFmU.png\",\"hero_image\":\"\\/uploads\\/23\\/03\\/1678140600lS8T5SkGWjUDMw00x8aR.png\",\"testimonial_cover\":\"\\/uploads\\/23\\/04\\/1680990550b4VGZjg5I0mHrS0ZEzEO.png\",\"integration_cover\":\"\\/uploads\\/23\\/04\\/1680691072MdDwD8iZV7nFu32OLg7Z.png\",\"integration_left\":\"\\/uploads\\/23\\/04\\/1680687785yK5jB6wU8F0njvElGAqE.png\",\"integration_right\":\"\\/uploads\\/23\\/04\\/1680687785b4Qk1bP8HMnMCuedEqOo.png\",\"hero_right_image\":\"\\/uploads\\/23\\/04\\/1680991267IpQIAwGSbY5ZIFRwO6Pp.png\",\"cta_logo\":\"\\/uploads\\/23\\/03\\/1678039536jzV8Ut6FTWgytwnEZxo0.png\",\"cta_thumbnail\":\"\\/uploads\\/23\\/03\\/1678139635o3AHoY7EGdexS7UuUajq.png\",\"platform_thumbnail\":\"\\/uploads\\/23\\/03\\/1678139743EuXomMHlbRJIEUobx62D.png\",\"account_area_thumbnail\":\"\\/uploads\\/23\\/03\\/1678140032Wxqq2w6cndL4uWiEHf8B.png\",\"account_area_top_thumbnail\":\"\\/uploads\\/23\\/03\\/1678039536eRShFlGn3Uw9tN1X14E0.png\",\"account_area_bottom_thumbnail\":\"\\/uploads\\/23\\/03\\/16780395365JXHyeVBXUVAldB1V5Se.png\",\"account_footer_left_image\":\"\\/uploads\\/23\\/03\\/16780395365VbXNjp8vpREwrrQ8R44.png\",\"account_footer_right_image\":\"\\/uploads\\/23\\/03\\/1678039536cX0XI21coIdJ3M1Im54A.png\",\"faq_cover\":\"\\/uploads\\/23\\/04\\/1680990550DfwMWKaP9MfCYR6fPued.png\",\"about_cover\":\"\\/uploads\\/23\\/04\\/1680989187xEbFX8vGfdBmWfMkb3Xo.gif\"}', 'en'),
(17, 'why-choose', '{\"title\":\"Why choose Zero To Hundred \\ud83c\\udf96\\ufe0f\",\"subtitle\":\"Get start\",\"left_button_link\":\"\\/pricing\",\"right_button_link\":\"\\/pricing\",\"left_block_title\":\"Active Customers\",\"left_block_value\":\"200\",\"center_block_title\":\"Total Customers\",\"center_block_value\":\"500\",\"right_block_title\":\"Positive Reviews\",\"right_block_value\":\"400\",\"left_button_image\":\"\\/uploads\\/23\\/03\\/1678120554l1bhGUjz28tmiBtCqTK6.png\",\"right_button_image\":\"\\/uploads\\/23\\/03\\/1678120554IAVDm9xBLZXYtGAamM0I.png\",\"left_block_image\":\"\\/uploads\\/23\\/03\\/1678120554hneDbhf9WG6aXvdV0h6q.png\",\"center_block_image\":\"\\/uploads\\/23\\/03\\/1678120554PcP79pqqlziQ71Yf1T70.png\",\"right_block_image\":\"\\/uploads\\/23\\/03\\/1678120554dGH99dtfF4slpDVVHjT1.png\"}', 'en'),
(18, 'contact-page', '{\"address\":\"Dubai Dear Al Braha\",\"country\":\"United Arab Emirates\",\"map_link\":\"https:\\/\\/www.google.com.bd\\/maps\\/@23.74591,90.3701368,15z\",\"contact1\":\"971569501867\",\"contact2\":\"971561500873\",\"email1\":\"support@to100msg.com\",\"email2\":\"contact@to100msg.com\"}', 'en'),
(19, 'about', '{\"about_image_1\":\"\\/uploads\\/23\\/03\\/1678140418eqwc9ocl8MfpeP0fEznT.png\",\"about_image_2\":\"\\/uploads\\/23\\/03\\/16781404191Btcr8D8FJTBo3SiTcQA.png\",\"breadcrumb_title\":\"About WhatServe\",\"section_title\":\"Over 12 years of experience in the IT Industry & Tech service\",\"experience\":\"12\",\"experience_title\":\"Years of Experience\",\"description\":\"Lorem ipsum dolor sit amet enim. Etiam ullamcorper. Suspendisse a pellentesque dui, non felis. Maecenas malesuada elit lectus felis, malesuada ultricies. Curabitur et ligula. Ut molestie a, ultricies porta <br> Lorem ipsum dolor sit amet enim. Etiam ullamcorper. Suspendisse a pellentesque dui, non felis. Maecenas malesuada elit lectus felis,\",\"button_title\":\"Check our work\",\"button_link\":\"\\/features\",\"facilities\":\"Fast support, Stable api response, Reasonable price, User-friendly UX, Regular features update\",\"introducing_video\":\"https:\\/\\/www.youtube.com\\/watch?v=Fu3MIwF-LJw\"}', 'en'),
(20, 'counter', '{\"experience\":\"12\",\"active_customers\":\"900\",\"positive_reviews\":\"200\",\"satisfied_customers\":\"800\"}', 'en'),
(21, 'theme_path', 'frontend.index-1', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `invoice_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `gateway_id` bigint(20) UNSIGNED NOT NULL,
  `amount` double DEFAULT NULL,
  `tax` double DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `will_expire` date DEFAULT NULL,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `group_name`, `created_at`, `updated_at`) VALUES
(1, 'about', 'web', 'Appearance', '2023-09-17 20:12:40', '2023-09-17 20:12:40'),
(2, 'blogs', 'web', 'Appearance', '2023-09-17 20:12:40', '2023-09-17 20:12:40'),
(3, 'blogs-category', 'web', 'Appearance', '2023-09-17 20:12:40', '2023-09-17 20:12:40'),
(4, 'blog-tags', 'web', 'Appearance', '2023-09-17 20:12:40', '2023-09-17 20:12:40'),
(5, 'faq', 'web', 'Appearance', '2023-09-17 20:12:40', '2023-09-17 20:12:40'),
(6, 'features', 'web', 'Appearance', '2023-09-17 20:12:40', '2023-09-17 20:12:40'),
(7, 'team', 'web', 'Appearance', '2023-09-17 20:12:40', '2023-09-17 20:12:40'),
(8, 'language', 'web', 'Appearance', '2023-09-17 20:12:40', '2023-09-17 20:12:40'),
(9, 'menu', 'web', 'Appearance', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(10, 'custom-page', 'web', 'Appearance', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(11, 'partners', 'web', 'Appearance', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(12, 'seo', 'web', 'Appearance', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(13, 'testimonials', 'web', 'Appearance', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(14, 'page-settings', 'web', 'Site Settings', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(15, 'admin', 'web', 'Site Settings', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(16, 'developer-settings', 'web', 'Site Settings', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(17, 'roles', 'web', 'Site Settings', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(18, 'apps', 'web', 'User Logs', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(19, 'contacts', 'web', 'User Logs', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(20, 'customer', 'web', 'User Logs', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(21, 'device', 'web', 'User Logs', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(22, 'notification', 'web', 'User Logs', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(23, 'schedule', 'web', 'User Logs', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(24, 'templates', 'web', 'User Logs', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(25, 'message-transactions', 'web', 'User Logs', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(26, 'cron-job', 'web', 'SAAS Functionalities', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(27, 'gateways', 'web', 'SAAS Functionalities', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(28, 'order', 'web', 'SAAS Functionalities', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(29, 'subscriptions', 'web', 'SAAS Functionalities', '2023-09-17 20:12:41', '2023-09-17 20:12:41'),
(30, 'support', 'web', 'SAAS Functionalities', '2023-09-17 20:12:41', '2023-09-17 20:12:41');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

CREATE TABLE `plans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `labelcolor` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iconname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` double DEFAULT NULL,
  `is_featured` int(11) NOT NULL DEFAULT '0',
  `is_recommended` int(11) NOT NULL DEFAULT '0',
  `is_trial` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `days` int(11) NOT NULL DEFAULT '0',
  `trial_days` int(11) DEFAULT NULL,
  `data` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `plans`
--

INSERT INTO `plans` (`id`, `title`, `labelcolor`, `iconname`, `price`, `is_featured`, `is_recommended`, `is_trial`, `status`, `days`, `trial_days`, `data`, `created_at`, `updated_at`) VALUES
(1, 'Starter', 'price-color-1', 'fas fa-star', 10, 1, 0, 0, 0, 30, 0, '{\"messages_limit\":\"1000\",\"contact_limit\":\"100\",\"device_limit\":\"3\",\"template_limit\":\"20\",\"apps_limit\":\"10\",\"chatbot\":\"true\",\"bulk_message\":\"false\",\"schedule_message\":\"false\",\"access_chat_list\":\"false\",\"access_group_list\":\"false\"}', '2023-03-05 23:29:25', '2024-08-27 17:56:25'),
(2, 'Enterprise', 'price-color-2', 'far fa-check-circle', 100, 1, 1, 1, 1, 30, 100, '{\"messages_limit\":\"-1\",\"contact_limit\":\"-1\",\"device_limit\":\"-1\",\"template_limit\":\"-1\",\"apps_limit\":\"-1\",\"chatbot\":\"true\",\"bulk_message\":\"true\",\"schedule_message\":\"true\",\"access_chat_list\":\"true\",\"access_group_list\":\"true\"}', '2023-03-05 23:30:39', '2024-08-27 18:05:09'),
(3, 'Basic', 'price-color-3', 'fab fa-angellist', 20, 1, 0, 0, 0, 30, 0, '{\"messages_limit\":\"-1\",\"contact_limit\":\"100\",\"device_limit\":\"100\",\"template_limit\":\"100\",\"apps_limit\":\"10\",\"chatbot\":\"false\",\"bulk_message\":\"false\",\"schedule_message\":\"true\",\"access_chat_list\":\"true\",\"access_group_list\":\"false\"}', '2023-03-05 23:32:49', '2024-08-27 17:57:31');

-- --------------------------------------------------------

--
-- Table structure for table `postcategories`
--

CREATE TABLE `postcategories` (
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `postcategories`
--

INSERT INTO `postcategories` (`post_id`, `category_id`) VALUES
(8, 7),
(8, 13),
(9, 7),
(9, 8),
(9, 12),
(9, 13),
(10, 6),
(10, 13),
(10, 14);

-- --------------------------------------------------------

--
-- Table structure for table `postmetas`
--

CREATE TABLE `postmetas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `postmetas`
--

INSERT INTO `postmetas` (`id`, `post_id`, `key`, `value`) VALUES
(1, 1, 'excerpt', 'A chatbot is always available to serve your customer 24/7. A chatbot can save you a lot of time and money by automating repetitive tasks like qualifying leads or answering questions of your customers. By offering instatily response to your customer, your business will build trust and boost conversions and sales.'),
(2, 2, 'excerpt', 'No, you only need a email to sign up.'),
(3, 3, 'excerpt', 'Yes, If you are unhappy with our service, we offer 30 days money-back guarantee on any plan.'),
(4, 4, 'excerpt', '{\"facebook\":\"https:\\/\\/www.facebook.com\\/\",\"twitter\":\"https:\\/\\/twitter.com\\/\",\"linkedin\":\"https:\\/\\/linkedin.com\\/\",\"instagram\":\"https:\\/\\/www.instagram.com\\/\"}'),
(5, 4, 'description', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'),
(6, 4, 'preview', '/uploads/23/03/1678125197LZ4zAxvVjarz0PrmZCqK.png'),
(7, 5, 'excerpt', '{\"facebook\":\"https:\\/\\/www.facebook.com\\/\",\"twitter\":\"https:\\/\\/twitter.com\\/\",\"linkedin\":\"https:\\/\\/linkedin.com\\/\",\"instagram\":\"https:\\/\\/www.instagram.com\\/\"}'),
(8, 5, 'description', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'),
(9, 5, 'preview', '/uploads/23/03/1678125246G7FoUHHxe2C88n1cVXCq.png'),
(10, 6, 'excerpt', '{\"facebook\":\"https:\\/\\/www.facebook.com\\/\",\"twitter\":\"https:\\/\\/twitter.com\\/\",\"linkedin\":\"https:\\/\\/linkedin.com\\/\",\"instagram\":\"https:\\/\\/www.instagram.com\\/\"}'),
(11, 6, 'description', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'),
(12, 6, 'preview', '/uploads/23/03/16781252849ApdWcy0jUhLRb9QtCL4.png'),
(13, 7, 'excerpt', '{\"facebook\":\"https:\\/\\/www.facebook.com\\/\",\"twitter\":\"https:\\/\\/twitter.com\\/\",\"linkedin\":\"https:\\/\\/linkedin.com\\/\",\"instagram\":\"https:\\/\\/www.instagram.com\\/\"}'),
(14, 7, 'description', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'),
(15, 7, 'preview', '/uploads/23/03/1678125323UINo4L0ZND1ErxlWCAFu.png'),
(16, 8, 'preview', '/uploads/23/03/1678128734p2mgTWEhEKwm5MsxhunY.png'),
(17, 8, 'short_description', 'In a world that’s increasingly getting commoditized, thanks to technology, it’s an open secret that customer focus is the real differentiator. This Gospel truth is germane to every business function, but in marketing it’s indispensable. Reason being the constantly changing needs, wants and desires of customers. New age marketing therefore, is all about unique individual experiences through tools that bring brands closer to their customer.'),
(18, 8, 'main_description', 'Today there’s literally an ocean when it comes to the number of available tools for marketers but none comes close to the effectiveness of QBM. Quality Based Messaging or QBM is a feature under WhatsApp business API which helps businesses engage customers through contextual messaging. These messages need to meet the quality criteria defined by WhatsApp and hence the name- Quality Based Messaging.'),
(19, 8, 'seo', '{\"title\":\"Boost your business growth with WhatsApp Quality Based Messaging\",\"description\":\"In a world that\\u2019s increasingly getting commoditized, thanks to technology, it\\u2019s an open secret that customer focus is the real differentiator. This Gospel truth is germane to every business function, but in marketing it\\u2019s indispensable. Reason being the constantly changing needs, wants and desires of customers. New age marketing therefore, is all about unique individual experiences through tools that bring brands closer to their customer.\",\"tags\":\"wa, whatsapp, devstation, qserve, whatsserve, whatserder\"}'),
(20, 9, 'preview', '/uploads/23/03/1678129064eIpoGudjOtETN0JhQRzG.png'),
(21, 9, 'short_description', 'In the competitive business landscape, if there’s one thing that has led to the massive growth of internet businesses, it is digital advertising. The $600 billion industry holds an outsized control on customers—- who buys what and thus to the fortunes of these businesses. An interesting aspect of digital advertising is its dynamic and ever-evolving nature, from search ads to video and voice search with the latest being Click to Chat ads. Click to Chat ads, although at a nascent stage currently,'),
(22, 9, 'main_description', 'In Feynman speak, Click to Chat ads are ads that are conversational in nature. With precise targeting, marketers are finding it to be much more effective in addressing the shortcomings of typical digital ads.\n\n         Before delving deeper into Click to Chat ads, it’s important to understand imperfections in the digital ad industry which have made way for this new form of advertising. The world moved from traditional mass media advertising to digital ads as the audience had moved online and targeting audience segments on digital was easy. \n\n         But while digital solved the problem of targeting, it lacked two-way conversations where users could be engaged and their doubts settled.\n\n         The customer does not have a choice today, if they want to connect with the advertised brand for clarity on product /service or instantly perform a transaction. Website landing pages are better suited for savvy internet users who are adept at browsing through multiple pages.They are not for technology newbies. Moreover, a landing page is not the ideal destination in case of products such as jewelry, furniture, real estate and financial services where guided selling works best. \n\n         Take for example- jewelry. A beautiful model wearing a stylish looking pendant set may entice a user to click on the ad and enter a landing page. But leaves this user unanswered for common questions such as- exchange policy, the kind of gemstones used in the pendant etc.'),
(23, 9, 'seo', '{\"title\":\"Click to Chat ads on WhatsApp- A vital tool for your marketing arsenal\",\"description\":\"In the competitive business landscape, if there\\u2019s one thing that has led to the massive growth of internet businesses, it is digital advertising. The $600 billion industry holds an outsized control on customers\\u2014- who buys what and thus to the fortunes of these businesses. An interesting aspect of digital advertising is its dynamic and ever-evolving nature, from search ads to video and voice search with the latest being Click to Chat ads. Click to Chat ads, although at a nascent stage currently,\",\"tags\":\"wa, whatsapp, devstation, wasender, whatsserve\",\"image\":\"\\/uploads\\/23\\/03\\/1678129064ZCzwbv9lHINvkGVXBH2R.png\"}'),
(24, 10, 'preview', '/uploads/23/03/16781292529emrzSmYnHCskq8JUxIb.png'),
(25, 10, 'short_description', 'ChatGPT (Conversational Generative Pre-trained Transformer) is a newly released open-source conversational AI platform. It has been praised for its ability to generate natural language responses to user inputs, and many have hailed it as the next step in creating more human-like conversations. However, despite its promise, certain limitations still prevent it from being a viable replacement for other conversational AI platforms. Let’s explore these limitations and how they can be addressed.'),
(26, 10, 'main_description', 'How is ChatGPT different from Conversational AI?\n        As an AI language model, ChatGPT can provide conversational capabilities that can be helpful for certain use cases, such as answering general questions or providing basic support. However, it is not designed to replace enterprise conversational AI platforms for several reasons:\n\n        Fine-tuning and customization: Enterprise conversational AI platforms can be customized to meet specific business needs and integrate with their existing systems of records, providing a more tailored solution. ChatGPT, on the other hand, is a general-purpose AI language model and may not be able to meet the specific needs of every business.\n        Security and compliance: Enterprise conversational AI platforms often have security and compliance features built-in, ensuring that sensitive data is protected and regulatory requirements are met. ChatGPT is not specifically designed for enterprise-level security and compliance requirements.\n        Integrations: Enterprise conversational AI platforms can integrate with other systems and applications, allowing for a more seamless experience for users. ChatGPT does not have the same level of integration capabilities.\n        Support and maintenance: Enterprise conversational AI platforms often provide support and maintenance services to ensure that the system is running smoothly and to address any issues that arise. ChatGPT does not provide this level of support and maintenance.\n        Scalability: Enterprise conversational AI platforms can be scaled to handle large volumes of user interactions, while ChatGPT may not be able to handle the same level of scalability.\n        In summary, while ChatGPT can provide conversational capabilities for certain use cases, it is not designed to replace enterprise conversational AI platforms, which offer greater customization, security, integration, support, maintenance, and scalability capabilities to meet the needs of large businesses.'),
(27, 10, 'seo', '{\"title\":\"Why ChatGPT Cannot Replace Conversational AI Platforms?\",\"description\":\"ChatGPT (Conversational Generative Pre-trained Transformer) is a newly released open-source conversational AI platform. It has been praised for its ability to generate natural language responses to user inputs, and many have hailed it as the next step in creating more human-like conversations. However, despite its promise, certain limitations still prevent it from being a viable replacement for other conversational AI platforms. Let\\u2019s explore these limitations and how they can be addressed.\",\"tags\":\"wa, whatsapp, devstation, qserve, whatsserve\",\"image\":\"\\/uploads\\/23\\/03\\/16781292529yMlP8qfUEaRjJic39bs.png\"}'),
(30, 12, 'excerpt', 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.'),
(31, 12, 'preview', '/uploads/23/03/1678130604XsBOBA2JdT4D3dUMsVPO.jpg'),
(32, 13, 'excerpt', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum'),
(33, 13, 'preview', '/uploads/23/03/1678130652BHfP85klZ25vaXpBU6AT.jpg'),
(34, 14, 'excerpt', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s'),
(35, 14, 'preview', '/uploads/23/03/1678130699E0RrnxKNI6tkb6Qc1eV1.jpg'),
(36, 15, 'excerpt', 'Boost digital finance adoption with instant balance inquiries, portfolio recommendations, hassle-free claims settlement, cross-sell and more'),
(37, 16, 'excerpt', 'Revolutionize your restaurant operations with WhatsApp-based ordering, meal and add-on recommendations, payments and real-time delivery updates'),
(38, 17, 'excerpt', 'Create multistage campaigns in just a few clicks and plan your campaigns ahead of time with pre-built templates'),
(39, 17, 'main_description', 'Create multistage campaigns in just a few clicks and plan your campaigns ahead of time with pre-built templates Adapt customer journeys based on real-time events. such as purchases, browses, or any event unique to your customers Seamlessly integrate with marketing tools and CRMs like Clevertap and Moengage to send tailored campaigns'),
(40, 17, 'preview', '/uploads/23/03/1678143851hf9IuC24SAhOJ1dLId94.png'),
(41, 17, 'banner', '/uploads/23/03/1678143446kru2cExnnwONsqF55Nc6.png'),
(42, 18, 'excerpt', 'WhatsApp lets you add buttons to message templates. There are two types of buttons: Quick replies and Call to action buttons. These buttons open up many opportunities for businesses worldwide to engage with their customers on WhatsApp, one of the most popular messaging applications.'),
(43, 18, 'main_description', 'WhatsApp lets you add buttons to message templates. There are two types of buttons: Quick replies and Call to action buttons. These buttons open up many opportunities for businesses worldwide to engage with their customers on WhatsApp, one of the most popular messaging applications. Quick replies let businesses define buttons that users can tap to respond. When a Quick reply is tapped, a message containing the button text is sent in the conversation. Call to action buttons trigger a phone call or open a website when tapped. Please note that at this time, WhatsApp does not support deeplinks. To use buttons, you need to submit them as part of a message template to WhatsApp. Once approved, templates containing buttons can be sent by sending the message text in your API request.'),
(44, 18, 'preview', '/uploads/23/03/1678144536donXXxCjluUjy3vZEjEO.png'),
(45, 18, 'banner', '/uploads/23/03/1678177857DqLCX7BJooFwWYFnY3mH.png'),
(46, 19, 'excerpt', 'If you are looking for how to set auto-reply in WhatsApp business and WhatsApp auto-reply message sample, you are at the right place. In this post, we’ll help you understand the nitty-gritty of WhatsApp Chatbots. To start off with, let’s talk about how auto-response for WhatsApp works.'),
(47, 19, 'main_description', 'Why do you need the WhatsApp auto-reply feature?\n        It is obvious that auto-reply is an essential feature for every kind of business.\n\n        But why? Let us elaborate.\n\n        Instant messaging, in its essence, is meant to be immediate at all times. WhatsApp as a platform has more than 2 billion users available and active at varied times.\n        Businesses move to WhatsApp to take advantage of this very fact, but unfortunately, this isn\'t always possible due to reasons like limited working hours and a shortage of human resources.\n\n        This is where WhatsApp Auto-replies come in. \n\n        With auto-replies, you can always be available to greet and respond to customers even outside your working hours. This allows you to: \n\n        Be available to your customers 24/7\n        Make a strong impression on new customers by greeting them with a customised welcome message.\n        Inform your customers about your available hours and set a response time expectation.\n        Collect customer data using a pre-chat survey quiz or through AI automated conversations\n        This increases customer satisfaction and gives your business an upper hand against competitors. WhatsApp auto replies make life much easier for all growing businesses.'),
(48, 19, 'preview', '/uploads/23/03/1678145544w3aon4jCrAciwsSaTXCo.png'),
(49, 19, 'banner', '/uploads/23/03/1678178152NI8xZNWqa96WzC13Aytg.gif'),
(50, 20, 'excerpt', 'WhatsApp users can schedule posts on the app to plan and send text, photos or videos. The posts can be scheduled for WhatsApp business or to send wishes on birthdays and festivals.'),
(51, 20, 'main_description', 'With 2 billion+ active users, WhatsApp is the most widely used communication app. WhatsApp allows you to share text messages, multi-media, location & now money. With all these useful features, you may want to schedule a WhatsApp message for wishing someone their birthday or remind your friends about some events. Or if you’re a business, you may want to schedule payment reminders on the last day of subscriptions or cart reminders to your customers’ WhatsApp. Or, your business needs to automate WhatsApp Business greeting messages to all new customers/subscribers.'),
(52, 20, 'preview', '/uploads/23/03/1678176166I16bhCDLteYzyEXmiydB.png'),
(53, 20, 'banner', '/uploads/23/03/16781761667IC0JxTR0A4nDQ3pPkPn.webp'),
(54, 21, 'excerpt', 'WA Bulk messaging is the dissemination of large numbers of messages for delivery to WASender software. It is used by media companies, banks and other enterprises and consumer brands for a variety of purposes including entertainment, enterprise and mobile marketing.'),
(55, 21, 'main_description', 'A bulk message is a message that is sent from a single WhatsApp Business user to multiple phone numbers at the same time. All receivers of the message will see it coming in as a private message. WhatsApp bulk messaging first was a consumer-only feature, but it’s now also available for businesses. For businesses, this means they can now also use WhatsApp for outbound marketing activities.'),
(56, 21, 'preview', '/uploads/23/03/167817697016QUKcDn2rlERcMDuR2p.png'),
(57, 21, 'banner', '/uploads/23/03/1678177795QbOsO2mocgkgO8NRF071.png'),
(58, 22, 'excerpt', 'Representational state transfer is a software architectural style that describes the architecture of the Web.'),
(59, 22, 'main_description', 'An API is a set of definitions and protocols for building and integrating application software. It’s sometimes referred to as a contract between an information provider and an information user—establishing the content required from the consumer (the call) and the content required by the producer (the response). For example, the API design for a weather service could specify that the user supply a zip code and that the producer reply with a 2-part answer, the first being the high temperature, and the second being the low.'),
(60, 22, 'preview', '/uploads/23/03/1678177358eT0wu71Go2ANWmiEVTrP.png'),
(61, 22, 'banner', '/uploads/23/03/16781773587loKRma922J59f5EOXHQ.png'),
(62, 23, 'excerpt', 'WASender is the best quaint james bond victoria sponge happy days cras.'),
(63, 24, 'excerpt', 'No you can simply register with your email'),
(64, 25, 'excerpt', 'WASender has supported free 10 days trial. You don\'t need to add credit card information.'),
(65, 26, 'description', 'What is Lorem Ipsum?\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\nWhy do we use it?\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).'),
(66, 26, 'seo', '{\"title\":\"terms and conditions\",\"description\":\"orem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, w\",\"tags\":\"wa, whatsapp, devstation, qserve, whatsserve\"}');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'blog',
  `status` int(11) NOT NULL DEFAULT '1',
  `featured` int(11) NOT NULL DEFAULT '1',
  `lang` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `slug`, `type`, `status`, `featured`, `lang`, `created_at`, `updated_at`) VALUES
(1, 'Why does your business need a chatbot?', 'why-does-your-business-need-a-chatbot', 'faq', 1, 1, 'en', '2023-03-06 15:17:03', '2023-03-06 15:17:03'),
(2, 'Do I need a credit card to sign up?', 'do-i-need-a-credit-card-to-sign-up', 'faq', 1, 1, 'en', '2023-03-06 15:17:50', '2023-03-06 15:17:50'),
(3, 'Do you offer a 30 day money-back guarantee?', 'do-you-offer-a-30-day-money-back-guarantee', 'faq', 1, 1, 'en', '2023-03-06 15:18:16', '2023-03-06 15:18:16'),
(4, 'Darlene Robertson', 'Product Manager', 'team', 1, 1, 'en', '2023-03-06 22:53:17', '2023-03-06 22:53:17'),
(5, 'Bessie Cooper', 'Vp People', 'team', 1, 1, 'en', '2023-03-06 22:54:06', '2023-03-06 22:54:06'),
(6, 'Eleanor Pena', 'Head of Design', 'team', 1, 1, 'en', '2023-03-06 22:54:44', '2023-03-06 22:54:44'),
(7, 'Rhonda Ortiz', 'Founder & CO', 'team', 1, 1, 'en', '2023-03-06 22:55:23', '2023-03-06 22:55:23'),
(8, 'Boost your business growth with WhatsApp Quality Based Messaging', 'boost-your-business-growth-with-whatsapp-quality-based-messaging', 'blog', 1, 1, 'en', '2023-03-06 23:50:45', '2023-03-06 23:50:45'),
(9, 'Click to Chat ads on WhatsApp- A vital tool for your marketing arsenal', 'click-to-chat-ads-on-whatsapp-a-vital-tool-for-your-marketing-arsenal', 'blog', 1, 1, 'en', '2023-03-06 23:57:44', '2023-03-06 23:57:44'),
(10, 'Why ChatGPT Cannot Replace Conversational AI Platforms?', 'why-chatgpt-cannot-replace-conversational-ai-platforms', 'blog', 1, 1, 'en', '2023-03-07 00:00:52', '2023-03-07 00:00:52'),
(12, 'Keith Powers', 'Developer', 'testimonial', 1, 1, '5', '2023-03-07 00:23:24', '2023-03-07 00:23:24'),
(13, 'Mary', 'Digital Marketer', 'testimonial', 1, 1, '5', '2023-03-07 00:24:12', '2023-03-07 00:25:36'),
(14, 'Clinton Ramosup', 'Freelancer', 'testimonial', 1, 1, '5', '2023-03-07 00:24:59', '2023-03-07 00:25:22'),
(15, 'Financial Services', 'financial-services', 'faq', 1, 1, 'en', '2023-03-07 00:30:09', '2023-03-07 00:30:09'),
(16, 'How it will take impact for Food & Restaurants business.', 'how-it-will-take-impact-for-food-restaurants-business', 'faq', 1, 1, 'en', '2023-03-07 00:31:09', '2023-03-07 00:31:09'),
(17, 'Template messaging', 'template-messaging', 'feature', 1, 1, 'en', '2023-03-07 03:24:43', '2023-03-07 03:24:43'),
(18, 'Actions buttons', 'actions-buttons', 'feature', 1, 1, 'en', '2023-03-07 04:15:36', '2023-03-07 04:16:21'),
(19, 'Auto Responder (BOT)', 'auto-responder-bot', 'feature', 1, 1, 'en', '2023-03-07 04:32:24', '2023-03-07 13:35:52'),
(20, 'Schedule message', 'schedule-message', 'feature', 1, 0, 'en', '2023-03-07 13:02:46', '2023-03-07 13:03:07'),
(21, 'Bulk message', 'bulk-message', 'feature', 1, 0, 'en', '2023-03-07 13:13:22', '2023-03-07 13:13:22'),
(22, 'RESET API for App', 'reset-api-for-app', 'feature', 1, 0, 'en', '2023-03-07 13:22:38', '2023-03-07 13:22:38'),
(23, 'Automatically sync in real time', 'top', 'faq', 1, 1, 'en', '2023-04-09 23:39:14', '2023-04-09 23:39:14'),
(24, 'Do I need a credit card to sign up?', 'top', 'faq', 1, 1, 'en', '2023-04-09 23:39:50', '2023-04-09 23:39:50'),
(25, 'Free 10 Days Trial', 'top', 'faq', 1, 1, 'en', '2023-04-09 23:40:59', '2023-04-09 23:40:59'),
(26, 'Terms and conditions', 'terms-and-conditions', 'page', 1, 1, 'en', '2023-04-09 23:40:59', '2023-04-09 23:40:59');

-- --------------------------------------------------------

--
-- Table structure for table `replies`
--

CREATE TABLE `replies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `device_id` bigint(20) UNSIGNED NOT NULL,
  `template_id` bigint(20) UNSIGNED DEFAULT NULL,
  `keyword` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply` text COLLATE utf8mb4_unicode_ci,
  `match_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'equal',
  `reply_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `api_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'superadmin', 'web', '2023-09-17 20:12:40', '2023-09-17 20:12:40');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1);

-- --------------------------------------------------------

--
-- Table structure for table `schedulecontacts`
--

CREATE TABLE `schedulecontacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `contact_id` bigint(20) UNSIGNED DEFAULT NULL,
  `schedulemessage_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status_code` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `schedulemessages`
--

CREATE TABLE `schedulemessages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `device_id` bigint(20) UNSIGNED DEFAULT NULL,
  `template_id` bigint(20) UNSIGNED DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `schedule_at` datetime DEFAULT NULL,
  `zone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` date DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smstesttransactions`
--

CREATE TABLE `smstesttransactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `app_id` bigint(20) UNSIGNED DEFAULT NULL,
  `device_id` bigint(20) UNSIGNED DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `charge` double DEFAULT NULL,
  `messaging_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_code` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smstransactions`
--

CREATE TABLE `smstransactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `device_id` bigint(20) UNSIGNED DEFAULT NULL,
  `app_id` bigint(20) UNSIGNED DEFAULT NULL,
  `template_id` bigint(20) UNSIGNED DEFAULT NULL,
  `from` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'from_api',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `messageTimestamp` bigint(20) DEFAULT NULL,
  `message_content` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smstransactions`
--

INSERT INTO `smstransactions` (`id`, `user_id`, `device_id`, `app_id`, `template_id`, `from`, `to`, `type`, `created_at`, `updated_at`, `messageTimestamp`, `message_content`, `message_id`) VALUES
(1, 2, 4, NULL, NULL, '971569501867', '971569501867', 'single-send', '2024-08-27 17:34:15', '2024-08-27 17:34:15', NULL, NULL, NULL),
(2, 2, 4, 1, NULL, '971569501867', '971569501867', 'from_api', '2024-08-27 17:36:17', '2024-08-27 17:36:17', NULL, '{\"text\":\"Example message\"}', ''),
(3, 2, 4, 1, NULL, '971569501867', '971553017011', 'from_api', '2024-08-27 17:37:02', '2024-08-27 17:37:02', NULL, '{\"text\":\"Example message\"}', '');

-- --------------------------------------------------------

--
-- Table structure for table `supportlogs`
--

CREATE TABLE `supportlogs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `is_admin` int(11) NOT NULL DEFAULT '0',
  `seen` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `support_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `supports`
--

CREATE TABLE `supports` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ticket_no` int(11) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '2',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE `templates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authkey` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wallet` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `meta` text COLLATE utf8mb4_unicode_ci,
  `plan` text COLLATE utf8mb4_unicode_ci,
  `plan_id` int(11) DEFAULT NULL,
  `will_expire` date DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `apiToken` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `avatar`, `authkey`, `wallet`, `role`, `email`, `phone`, `address`, `email_verified_at`, `password`, `status`, `meta`, `plan`, `plan_id`, `will_expire`, `remember_token`, `created_at`, `updated_at`, `apiToken`) VALUES
(1, 'Admin', 'uploads/avatar.png', NULL, NULL, 'admin', 'admin@admin.com', NULL, NULL, NULL, '$2y$10$2iKvLRIcaTnQuGuSHl43yeLboua45yEUm50ceWpxGT4FZteo0W41q', 1, NULL, NULL, NULL, NULL, NULL, '2023-09-17 20:12:40', '2023-09-17 20:12:40', NULL),
(2, 'TajEldeen  hassan', NULL, 'SHfzYxYqhmkjG5MZhWiw2WQX0S8RYfuEBsiBN1pFjqFMtTatEV', NULL, 'user', 'taghassan54@gmail.com', NULL, NULL, '2024-08-27 17:27:32', '$2y$10$pHQRmwmqxoPf2jgIpFuAEehk.D.GrYg8SDojD1/wY9cHqBewBdU8y', 1, NULL, '{\"messages_limit\":\"-1\",\"contact_limit\":\"-1\",\"device_limit\":\"-1\",\"template_limit\":\"-1\",\"apps_limit\":\"-1\",\"chatbot\":\"true\",\"bulk_message\":\"true\",\"schedule_message\":\"true\",\"access_chat_list\":\"true\",\"access_group_list\":\"true\"}', 2, '2026-09-30', NULL, '2023-09-17 20:13:45', '2023-09-17 20:13:45', NULL),
(3, 'tajEldeen', NULL, 'I2K2nuzRS1V5yTsj92TDornOMgjQaYVreKbU5KWRYX3WQfgvRh', NULL, 'user', 'taghassan55@gmail.com', NULL, NULL, NULL, '$2y$10$YB3pafYpO7SRkDq.JJdrF.Sj82QwUrkmQqNy8a9SoNMc3zuehqAd6', 1, NULL, '{\"messages_limit\":\"-1\",\"contact_limit\":\"-1\",\"device_limit\":\"-1\",\"template_limit\":\"-1\",\"apps_limit\":\"-1\",\"chatbot\":\"true\",\"bulk_message\":\"true\",\"schedule_message\":\"true\",\"access_chat_list\":\"true\",\"access_group_list\":\"true\"}', 2, '2023-09-27', NULL, '2023-09-18 00:27:08', '2023-09-18 00:27:08', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `webhooks`
--

CREATE TABLE `webhooks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `device_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci,
  `hook` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '2',
  `status_code` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `apps`
--
ALTER TABLE `apps`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `apps_uuid_unique` (`uuid`),
  ADD UNIQUE KEY `apps_key_unique` (`key`),
  ADD KEY `apps_user_id_foreign` (`user_id`),
  ADD KEY `apps_device_id_foreign` (`device_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categorymetas`
--
ALTER TABLE `categorymetas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categorymetas_category_id_foreign` (`category_id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contacts_user_id_foreign` (`user_id`);

--
-- Indexes for table `deviceorders`
--
ALTER TABLE `deviceorders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deviceorders_user_id_foreign` (`user_id`);

--
-- Indexes for table `devices`
--
ALTER TABLE `devices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `devices_uuid_unique` (`uuid`),
  ADD KEY `devices_user_id_foreign` (`user_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `gateways`
--
ALTER TABLE `gateways`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groupcontacts`
--
ALTER TABLE `groupcontacts`
  ADD KEY `groupcontacts_group_id_foreign` (`group_id`),
  ADD KEY `groupcontacts_contact_id_foreign` (`contact_id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `groups_user_id_foreign` (`user_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_user_id_foreign` (`user_id`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_plan_id_foreign` (`plan_id`),
  ADD KEY `orders_user_id_foreign` (`user_id`),
  ADD KEY `orders_gateway_id_foreign` (`gateway_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `plans`
--
ALTER TABLE `plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `postcategories`
--
ALTER TABLE `postcategories`
  ADD KEY `postcategories_post_id_foreign` (`post_id`),
  ADD KEY `postcategories_category_id_foreign` (`category_id`);

--
-- Indexes for table `postmetas`
--
ALTER TABLE `postmetas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `postmetas_post_id_foreign` (`post_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `replies`
--
ALTER TABLE `replies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `replies_user_id_foreign` (`user_id`),
  ADD KEY `replies_device_id_foreign` (`device_id`),
  ADD KEY `replies_template_id_foreign` (`template_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `schedulecontacts`
--
ALTER TABLE `schedulecontacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `schedulecontacts_contact_id_foreign` (`contact_id`),
  ADD KEY `schedulecontacts_schedulemessage_id_foreign` (`schedulemessage_id`);

--
-- Indexes for table `schedulemessages`
--
ALTER TABLE `schedulemessages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `schedulemessages_user_id_foreign` (`user_id`),
  ADD KEY `schedulemessages_device_id_foreign` (`device_id`),
  ADD KEY `schedulemessages_template_id_foreign` (`template_id`);

--
-- Indexes for table `smstesttransactions`
--
ALTER TABLE `smstesttransactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `smstesttransactions_user_id_foreign` (`user_id`),
  ADD KEY `smstesttransactions_app_id_foreign` (`app_id`),
  ADD KEY `smstesttransactions_device_id_foreign` (`device_id`);

--
-- Indexes for table `smstransactions`
--
ALTER TABLE `smstransactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `smstransactions_user_id_foreign` (`user_id`),
  ADD KEY `smstransactions_device_id_foreign` (`device_id`),
  ADD KEY `smstransactions_app_id_foreign` (`app_id`),
  ADD KEY `smstransactions_template_id_foreign` (`template_id`);

--
-- Indexes for table `supportlogs`
--
ALTER TABLE `supportlogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supportlogs_support_id_foreign` (`support_id`),
  ADD KEY `supportlogs_user_id_foreign` (`user_id`);

--
-- Indexes for table `supports`
--
ALTER TABLE `supports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supports_user_id_foreign` (`user_id`);

--
-- Indexes for table `templates`
--
ALTER TABLE `templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `templates_uuid_unique` (`uuid`),
  ADD KEY `templates_user_id_foreign` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `webhooks`
--
ALTER TABLE `webhooks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `webhooks_device_id_foreign` (`device_id`),
  ADD KEY `webhooks_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `apps`
--
ALTER TABLE `apps`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `categorymetas`
--
ALTER TABLE `categorymetas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deviceorders`
--
ALTER TABLE `deviceorders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `devices`
--
ALTER TABLE `devices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gateways`
--
ALTER TABLE `gateways`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `plans`
--
ALTER TABLE `plans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `postmetas`
--
ALTER TABLE `postmetas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `replies`
--
ALTER TABLE `replies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `schedulecontacts`
--
ALTER TABLE `schedulecontacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `schedulemessages`
--
ALTER TABLE `schedulemessages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `smstesttransactions`
--
ALTER TABLE `smstesttransactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `smstransactions`
--
ALTER TABLE `smstransactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `supportlogs`
--
ALTER TABLE `supportlogs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supports`
--
ALTER TABLE `supports`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `templates`
--
ALTER TABLE `templates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `webhooks`
--
ALTER TABLE `webhooks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `apps`
--
ALTER TABLE `apps`
  ADD CONSTRAINT `apps_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `apps_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `categorymetas`
--
ALTER TABLE `categorymetas`
  ADD CONSTRAINT `categorymetas_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contacts`
--
ALTER TABLE `contacts`
  ADD CONSTRAINT `contacts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `deviceorders`
--
ALTER TABLE `deviceorders`
  ADD CONSTRAINT `deviceorders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `devices`
--
ALTER TABLE `devices`
  ADD CONSTRAINT `devices_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `groupcontacts`
--
ALTER TABLE `groupcontacts`
  ADD CONSTRAINT `groupcontacts_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `groupcontacts_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `groups`
--
ALTER TABLE `groups`
  ADD CONSTRAINT `groups_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_gateway_id_foreign` FOREIGN KEY (`gateway_id`) REFERENCES `gateways` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `postcategories`
--
ALTER TABLE `postcategories`
  ADD CONSTRAINT `postcategories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `postcategories_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `postmetas`
--
ALTER TABLE `postmetas`
  ADD CONSTRAINT `postmetas_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `replies`
--
ALTER TABLE `replies`
  ADD CONSTRAINT `replies_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `replies_template_id_foreign` FOREIGN KEY (`template_id`) REFERENCES `templates` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `replies_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `schedulecontacts`
--
ALTER TABLE `schedulecontacts`
  ADD CONSTRAINT `schedulecontacts_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `schedulecontacts_schedulemessage_id_foreign` FOREIGN KEY (`schedulemessage_id`) REFERENCES `schedulemessages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `schedulemessages`
--
ALTER TABLE `schedulemessages`
  ADD CONSTRAINT `schedulemessages_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `schedulemessages_template_id_foreign` FOREIGN KEY (`template_id`) REFERENCES `templates` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `schedulemessages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `smstesttransactions`
--
ALTER TABLE `smstesttransactions`
  ADD CONSTRAINT `smstesttransactions_app_id_foreign` FOREIGN KEY (`app_id`) REFERENCES `apps` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `smstesttransactions_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `smstesttransactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `smstransactions`
--
ALTER TABLE `smstransactions`
  ADD CONSTRAINT `smstransactions_app_id_foreign` FOREIGN KEY (`app_id`) REFERENCES `apps` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `smstransactions_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `smstransactions_template_id_foreign` FOREIGN KEY (`template_id`) REFERENCES `templates` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `smstransactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `supportlogs`
--
ALTER TABLE `supportlogs`
  ADD CONSTRAINT `supportlogs_support_id_foreign` FOREIGN KEY (`support_id`) REFERENCES `supports` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `supportlogs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `supports`
--
ALTER TABLE `supports`
  ADD CONSTRAINT `supports_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `templates`
--
ALTER TABLE `templates`
  ADD CONSTRAINT `templates_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `webhooks`
--
ALTER TABLE `webhooks`
  ADD CONSTRAINT `webhooks_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `webhooks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
